// import React from "react";
import Topbar from "../../components/topbar/topbar";
import Sidebar from "../../components/sidebar/Sidebar";
import Feed  from "../../components/feed/Feedbar";
import Right from "../../components/rightbar/Rightbar";





function Home() {
  return (
    <>
    
       <Topbar/>
      <div className="homeContainer">
        
      <Sidebar/>
      <Feed/>
      <Right/> 
      </div>
      </>
      
    
  )
}

export default Home;




