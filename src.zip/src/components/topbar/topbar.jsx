import './topbar.css'
// import SearchIcon from '@mui/icons-material/Search';
// import PersonIcon from '@mui/icons-material/Person';
import {Search,Person,Chat,Notifications} from "@mui/icons-material";


export default function topbar() {
  return (
    <div className='topbarContainer'>
      <div className="topbarLeft">
        <span className='logo'>social</span>
      </div>
      <div className="topbarCenter"></div>
      <div className="searchbar">
        <Search className='searchIcon'/>
        <input placeholder='search for friend ' className='searchinput' />
      </div>
      <div className="topbarRight">
        <div className="topbarLinks">
          <span className="topbarLinks">Homepage</span>
          <span className="topbarLinks">Timeline</span>
        </div>
        <div className="topbarIcons">
          <div className="topbarIconItem">
            <Person/>
            <apan className="topbarIconBadgs"></apan>
            

          </div>
          <div className="topbarIconItem">
            <Chat/>
            <apan className="topbarIconBadgs"></apan>
            

          </div>
          <div className="tobarIconItem">
            <Notifications/>
            <apan className="topbarIconBadgs"></apan>
            

          </div>


        </div>
        <img src="/assets/person/ambani.jpg" alt="" className="topbarImg" />
      

      </div>
      
        
      
    </div>
  )
}
